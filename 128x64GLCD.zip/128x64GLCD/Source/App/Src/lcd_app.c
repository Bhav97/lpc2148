#include "type.h"
#include "utils.h"
#include "64x128GLCD.h"

#define MAX_THICKNESS 4

#define NUM_OF_ROWS 64
#define NUM_OF_COL 128
#define NUM_OF_PAGES 8

U8 frame_buf[NUM_OF_ROWS][NUM_OF_PAGES];

enum BRUSH_TYPE
{
	BRUSH_OFF,
	BRUSH_ON,
 	BRUSH_XOR
};

/**
*******************************************************************************
  Function Name : lcd_goto_xy()

  Description :	 

  Input :	

  Output :	none

  Note : 
*******************************************************************************
*/
void lcd_goto_xy(U8 x_address, U8 y_address)
{
  U8 page_num = x_address/NUM_OF_PAGES;

  LCD_SET_PAGE(PAGE1 + page_num, y_address);
}

/**
*******************************************************************************
  Function Name : put_pixel()

  Description :	 

  Input :	

  Output :	none

  Note : 
*******************************************************************************
*/
void put_pixel(U16 px, U16 py, U8 brush)
{
  U8 data = 0;
  U16 page_num = 0;
  
  if((px< NUM_OF_ROWS) && (py < NUM_OF_COL))
  {
    page_num = px / NUM_OF_PAGES;
    data = 1 << (px % 8);

    
    lcd_goto_xy(px,py);
    
    switch(brush)
    {
      case BRUSH_ON:
        frame_buf[px][page_num] |= data;
        break;
        
      case BRUSH_OFF:
        frame_buf[px][page_num] &= ~data;
        break;
        
      case BRUSH_XOR:
        frame_buf[px][page_num] ^= data;
        break;
        
      default:
        break;
    }
    LCD_WRITE_DATA(frame_buf[px][page_num]);
  }
}

/**
*******************************************************************************
  Function Name : lcd_draw_line()

  Description :	 

  Input :	

  Output :	none

  Note : 
*******************************************************************************
*/
void lcd_draw_line(U16 x1,U16 y1,U16 x2,U16 y2,U16 thickness)
{
  S16 dx,dy,dxabs,dyabs,i,px,py,sdx,sdy,x,y;
  U16 j = 0;
  
  if(thickness > MAX_THICKNESS)
  {
    thickness = MAX_THICKNESS;
  }
  dx = x2 - x1;
  dy = y2 - y1;
  
  sdx = SIGN(dx);
  sdy = SIGN(dy);
  
  dxabs = ABSOLUTE(dx);
  dyabs = ABSOLUTE(dy);
  
  x = 0; y = 0;
  
  px = x1;
  py = y1;
  
  if(dxabs >= dyabs)
  {
    for(i=0;i <=dxabs;i++)
    {
      y += dyabs;
      if(y >= dxabs)
      {
        y -= dxabs;
        py += sdy;
      }
      for(j = 0; j < thickness; j++)
      {
        put_pixel(px+j,py,BRUSH_ON);
      }
      px +=sdx;
    }
  }
  else
  {
    for(i=0; i<=dyabs;i++)
    {
      x += dxabs;
      if(x >= dyabs)
      {
        x -= dyabs;
        px += sdx;
      }
      for(j = 0; j < thickness; j++)
      {
      	put_pixel(px+j,py,BRUSH_ON);
      }
      py += sdy;
    }
  }
}

/**
*******************************************************************************
  Function Name : lcd_draw_circle()

  Description :	 

  Input :	

  Output :	none

  Note : Bresenham's Circle Algorithm 
         Taken from http://en.wikipedia.org/wiki/Bresenham's_line_algorithm 
*******************************************************************************
*/
void lcd_draw_circle(U16 x0, U16 y0, U16 radius)
{
  S32 f = 1 - radius;
  U16 ddF_x = 0;
  S32 ddF_y = -2 * radius;
  U16 x = 0;
  U16 y = radius;
  
  put_pixel(x0, y0 + radius,BRUSH_ON);
  put_pixel(x0, y0 - radius,BRUSH_ON);
  put_pixel(x0 + radius, y0,BRUSH_ON);
  put_pixel(x0 - radius, y0,BRUSH_ON);
  
  while(x < y)
  {
    if (f >= 0)
    {
      y--;
      ddF_y += 2;
      f += ddF_y;
    }
    x++;
    ddF_x += 2;
    f += ddF_x + 1;
    put_pixel(x0 + x, y0 + y,BRUSH_ON);
    put_pixel(x0 - x, y0 + y,BRUSH_ON);
    put_pixel(x0 + x, y0 - y,BRUSH_ON);
    put_pixel(x0 - x, y0 - y,BRUSH_ON);
    put_pixel(x0 + y, y0 + x,BRUSH_ON);
    put_pixel(x0 - y, y0 + x,BRUSH_ON);
    put_pixel(x0 + y, y0 - x,BRUSH_ON);
    put_pixel(x0 - y, y0 - x,BRUSH_ON);
  }
}
