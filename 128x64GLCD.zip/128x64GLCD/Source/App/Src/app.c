#include "lpc_2148.h"
#include "hardware.h"
#include "type.h"
#include "utils.h"
#include "64x128GLCD.h"

extern U8 data_table[];

/**
********************************************************************************************
	Function Name :	is_valid_ascii()

	Description :
	
	Input :	Void

	Output : Void

	Note :
**********************************************************************************************
*/
U8 is_valid_ascii(S8 key)
{
  U8 retval = FALSE;
  
  if(key >= ' ' && key <= '~')
    retval = TRUE;

  return retval;
}

/**
********************************************************************************************
	Function Name :	lcd_display_char()

	Description :
	
	Input :	Void

	Output : Void

	Note :
**********************************************************************************************
*/
void lcd_display_char(U8 charecter)
{
  U8 width = 0, index = 0, data = 0;
  
  width = get_width_of_char(charecter);
  for(index = 0; index < width; index++)
  {
    data = get_data_from_data_table(charecter, index);
    LCD_WRITE_DATA(data);
  }
}

/**
********************************************************************************************
	Function Name :	lcd_display_string()

	Description :
	
	Input :	Void

	Output : Void

	Note :
**********************************************************************************************
*/
void lcd_display_string(U8 *str)
{
  if(str == NULL)
    return;
    
  while(*str != (U8)NULL)
  {
    lcd_display_char(*str);
    str++;
  }
}

/**
*****************************************************************	
	Function Name :	main()

	Description :	To initialise system.

	Input :	none

	Output : int

	Note :
*****************************************************************
*/	
S32 main()
{
  U8 i,j;

  tn_arm_disable_interrupts();
  HardwareInit();
  tn_arm_enable_interrupts();
  LCD_INIT();
  LCD_CLEAR();

  LCD_SET_PAGE(PAGE1 + 2 , COL1);
  lcd_display_string("         WELCOME TO ");
  LCD_SET_PAGE(PAGE1 + 4 , COL1);
  lcd_display_string("    NGX TECHNOLOGIES");
  LCD_SET_PAGE(PAGE1 + 6 , COL1);
  lcd_display_string("         BANGALORE");
  while(1);

  return 1;
}

