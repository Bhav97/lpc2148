It works with  GCC ARM  3.4.3 and 4.10 (GNUARM + Cygwin)
Do not use GCC ARM 4.0.1 !!! It makes a few problems.


