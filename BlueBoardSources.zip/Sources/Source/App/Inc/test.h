#ifndef _TEST_H
#define _TEST_H

void process_lcd(void);
void process_adc(void);
void test_uart0(void);
void test_uart1(void);
void test_usb(void);
void test_sd_card(void);
void test_i2c_at24c256_flash(void);

#endif // _TEST_H
