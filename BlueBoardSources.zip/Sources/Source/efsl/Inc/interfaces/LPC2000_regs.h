/* based on LPC213x.h from Keil GmbH (keil.com/arm.com)  */

#ifndef LPC2000_regs_h
#define LPC2000_regs_h
#endif 
