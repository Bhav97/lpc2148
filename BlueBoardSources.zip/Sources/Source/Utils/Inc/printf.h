#ifndef _PRINTF_H
#define _PRINTF_H

int sprintf(char *out, const char *format, ...);

#endif

