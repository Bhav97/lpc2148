/*
TNKernel real-time kernel

Copyright � 2004,2006 Yuri Tiomkin
All rights reserved.

Permission to use, copy, modify, and distribute this software in source
and binary forms and its documentation for any purpose and without fee
is hereby granted, provided that the above copyright notice appear
in all copies and that both that copyright notice and this permission
notice appear in supporting documentation.

THIS SOFTWARE IS PROVIDED BY THE YURI TIOMKIN AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL YURI TIOMKIN OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
*/

/* ver 2.1  */

#include "tn.h"
#include "tn_utils.h"

//-- System uses two levels of priorities for own purpose:
//    - level 0  (highest) for system timers task
//    - level 31 (lowest) for system idle task

//-- System's  global variables
volatile int tn_int_counter;

CDLL_QUEUE tn_ready_list[TN_NUM_PRIORITY]; //-- all ready to run(RUNNABLE) tasks
CDLL_QUEUE tn_create_queue;                //-- all created tasks
volatile int tn_created_tasks_qty;                  //-- num of created tasks
CDLL_QUEUE tn_wait_timeout_list;           //-- all tasks that wait timeout expiration
CDLL_QUEUE tn_locked_mutexes_list;         //-- all locked mutexes
CDLL_QUEUE tn_blocked_tasks_list;          //-- for mutexes priority ceiling protocol

unsigned short tn_tslice_ticks[TN_NUM_PRIORITY]; //-- for round-robin only

volatile int tn_system_state;                //-- System state -(running/not running/etc.)

TN_TCB * tn_next_task_to_run;     //-- Task to be run after switch context
TN_TCB * tn_curr_run_task;        //-- Task that is running now


volatile int tn_enable_switch_context;
volatile int tn_context_switch_request;

volatile unsigned int tn_ready_to_run_bmp;
volatile unsigned long long tn_idle_count;   // 64-bit idle counter


  //-- System  timer task - priority 0  - highest
unsigned int tn_timer_task_stack[TN_TIMER_STACK_SIZE];
TN_TCB  tn_timer_task;
static void tn_timer_task_func(void * par);

 //-- System  idle task - priority (TN_NUM_PRIORITY-1) - lowest
unsigned int tn_idle_task_stack[TN_IDLE_STACK_SIZE];
TN_TCB  tn_idle_task;
static void tn_idle_task_func(void * par);
 //--
//static int sys_irr(void);


//----------------------------------------------------------------------------
// TN main function (never return)
//----------------------------------------------------------------------------
void tn_start_system(void)
{
   int i;
  //-- ToDo - initialize the sys log (if enabled)

   //-- Clear/set all globals(vars,lists,etc)

   for(i=0;i < TN_NUM_PRIORITY;i++)
   {
      queue_reset(&(tn_ready_list[i]));
      tn_tslice_ticks[i] = NO_TIME_SLICE;
   }

   queue_reset(&tn_create_queue);
   tn_created_tasks_qty = 0;

   tn_system_state = TN_ST_STATE_NOT_RUN;

   tn_enable_switch_context = 1;
   tn_ready_to_run_bmp = 0;

   tn_context_switch_request = 0;
   tn_int_counter = 0;

   tn_next_task_to_run = NULL;
   tn_curr_run_task    = NULL;


   queue_reset(&tn_locked_mutexes_list);
   queue_reset(&tn_blocked_tasks_list);

  //-- System tasks

   queue_reset(&tn_wait_timeout_list);

   //--- Timer task
   tn_task_create((TN_TCB*)&tn_timer_task,             //-- task TCB
                 tn_timer_task_func,             //-- task function
                 0,                                 //-- task priority
                 &(tn_timer_task_stack           //-- task stack first addr in memory
                    [TN_TIMER_STACK_SIZE-1]),
                 TN_TIMER_STACK_SIZE,            //-- task stack size (in int,not bytes)
                 NULL,                              //-- task function parameter
                 TN_TASK_TIMER                   //-- Creation option
                 );

   //--- Idle task
   tn_task_create((TN_TCB*)&tn_idle_task,              //-- task TCB
                 tn_idle_task_func,              //-- task function
                 TN_NUM_PRIORITY-1,              //-- task priority
                 &(tn_idle_task_stack            //-- task stack first addr in memory
                    [TN_IDLE_STACK_SIZE-1]),
                 TN_IDLE_STACK_SIZE,             //-- task stack size (in int,not bytes)
                 NULL,                              //-- task function parameter
                 TN_TASK_IDLE                    //-- Creation option
                 );

    //-- Activate timer & idle tasks
   task_to_runnable(&tn_idle_task);
   task_to_runnable(&tn_timer_task);

   tn_curr_run_task = &tn_idle_task;  //-- otherwise it is NULL

   //-- Run OS - first context switch
   tn_start_exe();
}
//----------------------------------------------------------------------------
static void tn_timer_task_func(void * par)
{
   //-- User application init - user's objects initial (tasks etc.) creation
   tn_app_init();
   //-- Enable interrupt here ( include tick int)
   tn_cpu_int_enable();
   //-------------------------------------------------------------------------

   for(;;)
   {
      tn_task_sleep(TN_WAIT_INFINITE);
   }
}

//----------------------------------------------------------------------------
//  In fact, this task is always in RUNNABLE state
//----------------------------------------------------------------------------
static void tn_idle_task_func(void * par)
{
   for(;;)
   {
      tn_idle_count++;
   }
}

//--- Set time slice ticks value for priority for round-robin scheduling
//--- If value is NO_TIME_SLICE there are no round-robin scheduling
//--- for tasks with priority. NO_TIME_SLICE is default value.
//----------------------------------------------------------------------------
int tn_sys_tslice_ticks(int priority,int value)
{
   TN_INTSAVE_DATA

   TN_CHECK_NON_INT_CONTEXT

   tn_disable_interrupt();

   if(priority <= 0 || priority >= TN_NUM_PRIORITY-1 ||
                                value < 0 || value > MAX_TIME_SLICE)
      return TERR_WRONG_PARAM;

   tn_tslice_ticks[priority] = value;

   tn_enable_interrupt();
   return TERR_NO_ERR;
}


//----------------------------------------------------------------------------
void  tn_tick_int_processing()
{
   TN_INTSAVE_DATA_INT
   volatile TN_TCB * task;           //-- Need volatile here only to solve
   volatile CDLL_QUEUE * curr_que;   //-- IAR(c) compiler's high optimization mode problem
   volatile CDLL_QUEUE * pri_queue;
   volatile int priority;


   TN_CHECK_INT_CONTEXT_NORETVAL

   tn_idisable_interrupt();

//-------  Round -robin ( if uses)

   priority  = tn_curr_run_task->priority;

   if(tn_tslice_ticks[priority] != NO_TIME_SLICE)
   {
      tn_curr_run_task->tslice_count++;
      if(tn_curr_run_task->tslice_count > tn_tslice_ticks[priority])
      {
         tn_curr_run_task->tslice_count = 0;

         pri_queue = &(tn_ready_list[priority]);
        //-- If ready queue is not empty and qty  of queue's tasks > 1
         if(!(is_queue_empty((CDLL_QUEUE *)pri_queue)) && pri_queue->next->next != pri_queue)
         {
           //-- Remove task from tail and add it to the head of
           //-- ready queue for current priority
            curr_que = queue_remove_tail(&(tn_ready_list[priority]));
            queue_add_head(&(tn_ready_list[priority]),(CDLL_QUEUE *)curr_que);
         }
      }
   }

//------------ OS timer tick -------------------------------------

  if(!is_queue_empty((CDLL_QUEUE*)&tn_wait_timeout_list))
  {
     curr_que = tn_wait_timeout_list.next;
     for(;;)
     {
        task = get_task_by_timer_queque((CDLL_QUEUE*)curr_que);
        if(task->tick_count > 0 && task->tick_count != TN_WAIT_INFINITE)
        {
           task->tick_count--;
           if(task->tick_count == 0) //-- Time out expiried
           {
              if(task_wait_complete((TN_TCB*)task))
              {
                 tn_context_switch_request = TRUE;
                 task->task_wait_rc = TERR_TIMEOUT; //???
              }
           }
        }
        if(curr_que->next == &tn_wait_timeout_list) //-- last
           break;
        else
           curr_que = curr_que->next;
     }
  }

  tn_ienable_interrupt();
//--------------

}
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------


