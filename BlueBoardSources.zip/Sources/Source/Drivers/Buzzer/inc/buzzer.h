#ifndef _BUZZER_H
#define _BUZZER_H

void buzzer_on();
void turn_off_buzzer();


#endif // _BUZZER_H
