#ifndef _DAC_H
#define _DAC_H
#include "type.h"

void init_dac(void);
void start_dac_conversion(U16 digital_value);

#endif

