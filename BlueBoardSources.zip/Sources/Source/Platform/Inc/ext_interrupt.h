#ifndef _EXT_INTERRUPT_
#define _EXT_INTERRUPT_

void init_ext_interrupt(void);

#endif // _EXT_INTERRUPT_
