#include "type.h"
#include "hardware.h"

void test_all_peripherals(void)
{
  U8 ch=0;

  test_leds();
  test_uart0();
  test_uart1();
  test_sd_card();
  test_i2c_at24c256_flash();
  if(get_USB_enumeration_status())
  {
    test_usb();
  }

  while(1)
  {
    if(keyhit())
    {
      process_lcd();
    }
    if(uart0Receive(&ch, sizeof(ch)) != -1)
    {
      test_uart0();
    }
    if(uart1Receive(&ch,sizeof(ch)) != -1)
    {
      test_uart1();
    }
    if(VCOM_read(sizeof(ch),&ch))
    {
      test_usb();
    }
    process_adc();      
  }
}

/**
*****************************************************************	
	Function Name :	main()

	Description :	To initialise system.

	Input :	none

	Output : int

	Note :
*****************************************************************
*/	
S32 main()
{
  tn_arm_disable_interrupts();

  HardwareInit();	
  tn_arm_enable_interrupts();
  
  test_all_peripherals();
  return 1;
}






