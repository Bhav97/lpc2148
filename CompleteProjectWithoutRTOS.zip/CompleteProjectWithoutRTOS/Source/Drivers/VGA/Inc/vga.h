#ifndef _VGA_H
#define _VGA_H

void init_vga(void);

#endif // _VGA_H
