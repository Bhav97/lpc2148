#ifndef _BUZZER_H
#define _BUZZER_H

void turn_on_buzzer(void);
void turn_off_buzzer(void);


#endif // _BUZZER_H
