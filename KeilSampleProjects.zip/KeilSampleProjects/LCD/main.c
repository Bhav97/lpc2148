#include "lcd.h"

int main (void) 
{
  init_lcd();

  while (1)  
  {
  }
}
